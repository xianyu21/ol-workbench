AxHub 原型工作台 · 本地服务版
================================

这是一个纯 Node.js 实现，仅使用 Node 内置模块，无需 npm install。

【启动方式】
  node axhub-server.js [AxHub根目录] [--port N] [--no-open]

示例：
  # 用默认端口（随机）启动，数据源为当前目录
  node axhub-server.js

  # 指定真实的 AxHub 导出目录
  node axhub-server.js "D:/你的AxHub导出目录"

  # 指定端口 8080
  node axhub-server.js --port 8080

  # 不自动打开浏览器
  node axhub-server.js --no-open

启动后控制台会打印工作台地址，例如：
  http://localhost:随机端口/_axviewer
在浏览器打开该地址即可使用。

【环境要求】
  Node.js（建议 16+），从 https://nodejs.org 下载安装后，
  在命令行进入本目录执行上面的 node 命令即可。

【文件说明】
  axhub-server.js  —— 本地静态服务器 + 文件扫描 + 工作台路由
  axhub-viewer.html —— 工作台 UI（左侧项目列表 + 顶部 tab 栏 + iframe 预览）
                     由服务器在 /_axviewer 路由返回，iframe 同源加载 AxHub 页面
